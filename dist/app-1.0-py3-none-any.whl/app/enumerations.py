from enum import Enum, unique

@unique
class Invocation(Enum):
	SCREENING = 1