questionaireViewType = ('single', 'slide');

questionaireSectionType = ('static', 'dynamic')
