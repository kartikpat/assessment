from flask import Blueprint

questionAssociationWithQuestionaire = Blueprint('questionAssociationWithQuestionaire', __name__)

from . import route