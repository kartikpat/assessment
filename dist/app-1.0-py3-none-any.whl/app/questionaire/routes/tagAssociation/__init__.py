from flask import Blueprint

tagAssociationWithQuestionaire = Blueprint('tagAssociationWithQuestionaire', __name__)

from . import route