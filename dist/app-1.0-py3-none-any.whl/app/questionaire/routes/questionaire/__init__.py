from flask import Blueprint

questionaire = Blueprint('questionaire', __name__)

from . import route