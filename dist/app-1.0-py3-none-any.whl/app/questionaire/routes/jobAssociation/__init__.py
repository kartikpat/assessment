from flask import Blueprint

jobAssociation = Blueprint('jobAssociation', __name__)

from . import route