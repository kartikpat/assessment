from flask import Blueprint

tagAssociationWithQuestion = Blueprint('tagAssociationWithQuestion', __name__)

from . import route